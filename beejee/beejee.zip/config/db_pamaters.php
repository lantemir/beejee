<?php
	
return array(
	'host' =>'localhost',
	'dbname' => 'beejee',
	'user' => 'root',
	'pass' => 'beejee777'
);

?>