<meta charset="utf-8">
<meta name="viewport" content="width=device-width">

<link rel="stylesheet" type="text/css" href="<?php uri(); ?>design/css/responsive.css">
<link rel="stylesheet" type="text/css" href="<?php uri(); ?>design/css/fonts.css">
<link rel="stylesheet" type="text/css" href="<?php uri(); ?>design/css/main.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">